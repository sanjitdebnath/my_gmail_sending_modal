<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $fullname = $_POST["fullname"];
    $age = $_POST["age"];
    $education = $_POST["education"];
    $institute = $_POST["institute"];
    $study = $_POST["study"];
    $work_experience = $_POST["work_experience"];
    $job_title = $_POST["job_title"];
    $company_name = $_POST["company_name"];
    $job_duties = $_POST["job_duties"];
    $admission_institute = $_POST["admission_institute"];
    $program_study = $_POST["program_study"];
    $applying_country = $_POST["applying_country"];
    $future_goals = $_POST["future_goals"];
    $english_listening = $_POST["english_listening"];
    $english_reading = $_POST["english_reading"];
    $english_speaking = $_POST["english_speaking"];
    $english_writing = $_POST["english_writing"];
    $tuition_paid = $_POST["tuition_paid"];
    $tuition_fee = $_POST["tuition_fee"];
    $gic = $_POST["gic"];
    $gic_fee = $_POST["gic_fee"];



    $content = "<pre>$fullname
$email
Visa Officer
High Commission of Canada
Subject: Statement of Purpose for studying in Canada

Dear Sir/Madam,

I would like to take this opportunity to introduce myself as a passionate individual with a strong desire to pursue a career in the field of software development.
My name is $fullname, and I am a $age-year-old student from $applying_country
I have recently completed my Bachelor's Degree in $education from $institute

During my undergraduate studies, I developed a deep interest in software development and programming.
I have always been fascinated by the way technology can be used to solve complex problems and improve people's lives.
To further enhance my knowledge and skills in this field, I have decided to pursue a program of study in Canada.

After extensive research, I have found that the Computer Science program at (Education Institution Name) is the perfect fit for my academic and career goals.
The program offers a comprehensive curriculum that covers all major concepts of computer science, including software development, algorithms, and data structures.
The interdisciplinary approach of the program will provide me with a well-rounded understanding of the field and prepare me for the challenges of the industry.

Studying at (Education Institution Name) will also give me the opportunity to learn from highly experienced and skilled faculty members.
The institution is known for its excellent facilities and resources, which will greatly support my academic pursuits.
I believe that the knowledge and skills I will gain from this program will be invaluable in my future career as a senior software developer.

Canada is renowned for its world-class education system, making it an ideal destination for international students like myself.
The country offers a safe and peaceful environment, along with excellent healthcare facilities.
Canadian institutes provide a dynamic and innovative learning environment, where students can develop their true potential.
The qualifications obtained from Canadian institutions are highly respected worldwide and will provide a strong foundation for my career.

Furthermore, studying in Canada will expose me to a diverse community of students from different cultures and backgrounds.
This multicultural environment will not only enhance my communication skills but also broaden my horizons and help me develop a global perspective.

Upon completion of my studies in Canada, my goal is to return to India and contribute to the growth of the software development industry.
India is experiencing rapid growth in the technology sector, and there is a high demand for skilled software developers.
I believe that the knowledge and expertise gained from my program in Canada will enable me to make a significant impact in this industry.

In terms of finances, I have already paid the first year's tuition fee of $tuition_fee and have a Guaranteed Investment Certificate (GIC) to cover my living expenses.
Additionally, my family is fully supportive of my education and will provide financial assistance if needed.

Dear Madam/Sir, I assure you that if granted the opportunity to study in Canada, I will abide by all the rules and regulations set by the Canadian government, local authorities, and the educational institution.
I have attached all the necessary documents to support my visa application and kindly request you to process it as soon as possible.

Thank you for considering my application. I am grateful for your time and attention.

Sincerely,
$fullname
";

    $_SESSION['content'] = $content;
    $_SESSION['email'] = $email;
}

require_once 'vendor/autoload.php';
$credentialsPath = 'credentials.json';

$SCOPES = array(
    'https://www.googleapis.com/auth/gmail.compose',
    'https://www.googleapis.com/auth/documents',
    'https://www.googleapis.com/auth/drive' // Add this line
);
$client = new Google_Client();
$client->setAuthConfig($credentialsPath);
$client->addScope($SCOPES);
$client->setAccessType('offline');

$REDIRECT_URI = "http://localhost/TestData/process_form.php";

if (isset($_SESSION['google_token'])) {
    $accessToken = $_SESSION['google_token'];
    $client->setAccessToken($accessToken);
    if ($client->isAccessTokenExpired()) {
        $client->fetchAccessTokenWithRefreshToken($_SESSION['google_token']['refresh_token']);
        $_SESSION['google_token'] = $client->getAccessToken();
    }
} elseif ($_GET['code']) {
    $accessToken = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    $_SESSION['google_token'] = $accessToken;
    header('Location:' . filter_var($REDIRECT_URI, FILTER_SANITIZE_URL));
    exit;
} else {
    $authUrl = $client->createAuthUrl();
    header('Location:' . filter_var($authUrl, FILTER_SANITIZE_URL));
    exit;
}
$driveService = new Google_Service_Drive($client);
$service = new Google_Service_Docs($client);

$document = new Google_Service_Docs_Document([
    'title' => 'My New Document',
]);

try {
    $document = $service->documents->create($document);

    $driveService->permissions->create(
        $document->documentId,
        new Google_Service_Drive_Permission([
            'role' => 'reader',
            'type' => 'anyone',
        ])
    );

    $request = new Google_Service_Docs_Request([
        'insertText' => [
            'location' => [
                'index' => 1,
            ],
            'text' => strip_tags($_SESSION['content']),
        ],
    ]);

    unset($_SESSION['content']);

    $batchUpdateRequest = new Google_Service_Docs_BatchUpdateDocumentRequest([
        'requests' => [$request],
    ]);

    $service->documents->batchUpdate($document->documentId, $batchUpdateRequest);
    $documentId = $document->documentId;

    $documentUrl = "https://docs.google.com/document/d/$documentId/edit";
    $service_one = new Google_Service_Gmail($client);
    $message = new Google_Service_Gmail_Message();

    $rawMessage = 'To: ' . $_SESSION['email'] .
    "\r\n" .
    'Subject: ' . "Statement of Purpose for studying in Canada" .
    "\r\n" .
    "Content-Type: text/html; charset=utf-8\r\n" . // Add Content-Type header
    "\r\n".$documentUrl;
    
    $base64UrlMessage = rtrim(strtr(base64_encode($rawMessage), '+/', '-_'), '=');
    
    $message->setRaw($base64UrlMessage);
    
    $sentMessage = $service_one->users_messages->send('me', $message);

    if ($sentMessage) {
        header("Location: http://localhost/TestData/frontEnd.html");
    }

    echo "File Send successfully";
} catch (Exception $e) {
    echo 'An error occurred: ' . $e->getMessage();
}
